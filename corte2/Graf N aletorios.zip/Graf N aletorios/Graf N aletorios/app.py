import pandas as pd
import matplotlib.pyplot as plt
from io import BytesIO
import base64
import random
import os

from flask import Flask, render_template_string, request, send_file, redirect, url_for

# --- Configuración ---
NOMBRE_ARCHIVO_CSV = 'numeros_aleatorios.csv'
COLUMNA_VALOR = 'Numero_Aleatorio'

# Inicialización de Flask
app = Flask(__name__)

# Adaptación de la función de generación (sin guardar en disco, solo retorna la lista)
def generar_aleatorios(n):
    """Genera 'n' números aleatorios de punto flotante en el rango (0, 1) estricto."""
    if not isinstance(n, int) or n <= 0:
        return []

    min_val = 1e-9
    max_val = 1 - 1e-9
    numeros_aleatorios = [random.uniform(min_val, max_val) for _ in range(n)]
    return numeros_aleatorios

# Adaptación de la función de graficación para Flask
def graficar_numeros(numeros):
    """
    Toma una lista de números y genera una gráfica PNG, devolviendo su codificación
    en Base64 para incrustar directamente en HTML.
    """
    if not numeros:
        return None

    y_valores = numeros
    x_orden = list(range(len(y_valores)))

    # 5. Crear la gráfica
    plt.figure(figsize=(10, 5))

    # Gráfica de línea y puntos
    plt.plot(x_orden, y_valores, marker='o', linestyle='-', color='teal',
             label='Número vs. Orden', markersize=3, linewidth=1, alpha=0.7)

    # 6. Configurar los títulos y etiquetas
    plt.title(f'Gráfico de Valores Aleatorios (N={len(y_valores)})', fontsize=14, weight='bold')
    plt.xlabel('Orden / Índice (Posición)')
    plt.ylabel('Valor del Número (entre 0 y 1)')

    # Ajustes visuales
    plt.ylim(0, 1) # Asegura el rango de 0 a 1
    plt.axhline(y=0.5, color='red', linestyle='--', linewidth=1, alpha=0.6, label='Referencia 0.5')

    plt.grid(True, linestyle=':', alpha=0.6)
    plt.legend()
    plt.tight_layout()

    # Guardar la gráfica en un búfer en memoria (no en disco)
    buffer = BytesIO()
    plt.savefig(buffer, format='png')
    plt.close() # Importante para liberar la memoria de la gráfica
    buffer.seek(0)

    # Codificar en Base64 para el HTML
    imagen_base64 = base64.b64encode(buffer.read()).decode('utf-8')
    return imagen_base64


# --- RUTAS DE FLASK ---

@app.route('/', methods=['GET', 'POST'])
def index():
    """Maneja la página principal y el procesamiento del formulario."""
    imagen_base64 = None
    mensaje = None

    if request.method == 'POST':
        try:
            # 1. Obtener la cantidad del formulario
            n_numeros = int(request.form.get('cantidad', 0))

            if n_numeros <= 0:
                mensaje = "⚠️ Por favor, ingrese un número entero positivo."
            else:
                # 2. Generar los números
                numeros = generar_aleatorios(n_numeros)

                # 3. Graficar
                imagen_base64 = graficar_numeros(numeros)

                if imagen_base64:
                    mensaje = f"✅ ¡Éxito! Se generaron y graficaron **{n_numeros}** números aleatorios."
                else:
                    mensaje = "❌ Error al generar o graficar los números."

        except ValueError:
            mensaje = "❌ Entrada no válida. Por favor, ingrese un número entero."
        except Exception as e:
            mensaje = f"❌ Ocurrió un error inesperado: {e}"

    # 4. Renderizar la plantilla HTML con el resultado
    return render_template_string(HTML_TEMPLATE, imagen=imagen_base64, mensaje=mensaje)

# Contenido HTML (incrustado aquí para simplicidad)
HTML_TEMPLATE = """
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Generador y Graficador de Números Aleatorios</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; margin: 40px; background-color: #f4f7f6; color: #333; }
        .container { max-width: 900px; margin: auto; padding: 20px 30px; background: white; border-radius: 12px; box-shadow: 0 4px 8px rgba(0,0,0,0.1); }
        h1 { color: #008080; border-bottom: 3px solid #008080; padding-bottom: 10px; margin-bottom: 20px; }
        form { background: #e9f5f5; padding: 20px; border-radius: 8px; margin-bottom: 30px; display: flex; align-items: center; gap: 15px; }
        input[type="number"] { padding: 10px; border: 1px solid #ccc; border-radius: 5px; flex-grow: 1; max-width: 200px; }
        button { background-color: #008080; color: white; padding: 10px 15px; border: none; border-radius: 5px; cursor: pointer; transition: background-color 0.3s ease; }
        button:hover { background-color: #006666; }
        .mensaje { padding: 15px; border-radius: 5px; margin-top: 20px; font-weight: bold; }
        .mensaje.exito { background-color: #d4edda; color: #155724; border: 1px solid #c3e6cb; }
        .mensaje.error { background-color: #f8d7da; color: #721c24; border: 1px solid #f5c6cb; }
        .grafica-container { text-align: center; margin-top: 30px; border-top: 1px dashed #ccc; padding-top: 20px; }
        img { max-width: 100%; height: auto; border: 1px solid #ddd; border-radius: 8px; box-shadow: 0 2px 4px rgba(0,0,0,0.05); }
    </style>
</head>
<body>
    <div class="container">
        <h1>✨ Generador y Graficador de Números Aleatorios (0-1)</h1>

        <form method="POST" action="/">
            <label for="cantidad">
                <strong>Cantidad de números a generar:</strong>
            </label>
            <input type="number" id="cantidad" name="cantidad" min="1" required placeholder="Ej: 1000">
            <button type="submit">Generar y Graficar</button>
        </form>

        {% if mensaje %}
            <div class="mensaje {% if '¡Éxito!' in mensaje %}exito{% else %}error{% endif %}">
                {{ mensaje|safe }}
            </div>
        {% endif %}

        {% if imagen %}
            <div class="grafica-container">
                <h2>📊 Resultado de la Graficación</h2>
                <img src="data:image/png;base64,{{ imagen }}" alt="Gráfico de Números Aleatorios">
            </div>
        {% endif %}

    </div>
</body>
</html>
"""

if __name__ == '__main__':
    # Iniciar la aplicación Flask
    # Accede desde tu navegador a http://127.0.0.1:5000/
    print("\n--- Servidor Flask Iniciado ---")
    print("Accede a: http://127.0.0.1:5000/")
    app.run(debug=True)